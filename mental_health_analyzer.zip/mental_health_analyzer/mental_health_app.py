from transformers import pipeline
import streamlit as st

classifier = pipeline(
    "text-classification",
    model="bhadresh-savani/distilbert-base-uncased-emotion",
    return_all_scores=True
)

def map_emotions(emotion_scores):
    categories = {"Depression": 0, "Anxiety": 0, "Stress": 0}
    for e in emotion_scores:
        label = e["label"].lower()
        score = e["score"]
        if label in ["sadness", "disappointment"]:
            categories["Depression"] += score
        if label in ["fear", "nervousness"]:
            categories["Anxiety"] += score
        if label in ["anger", "frustration"]:
            categories["Stress"] += score
    return categories

st.title("🧠 Mental Health Analyzer")
st.write("✏️ Type something and see if it shows signs of 😞 depression, 😰 anxiety or 😡 stress.")

text = st.text_area("💬 Enter text here:")

if st.button("🔍 Analyze"):
    if not text.strip():
        st.warning("⚠️ Please enter some text.")
    else:
        results = classifier(text)[0]
        st.subheader("🎭 Emotions:")
        for r in results:
            st.write(f"{r['label']} : {round(r['score'], 2)}")
        st.subheader("🩺 Mental Health:")
        mental_results = map_emotions(results)
        for category, score in mental_results.items():
            if score > 0.5:
                st.write(f"{category} : {round(score, 2)} ⚠️ High")
            else:
                st.write(f"{category} : {round(score, 2)} ✅ Normal")
